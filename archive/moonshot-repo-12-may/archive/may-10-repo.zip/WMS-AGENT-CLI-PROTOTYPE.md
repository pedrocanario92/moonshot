# WMS Agent CLI — Unified Prototype

**File:** `wms-unified.html`  
**Stack:** Vanilla HTML / CSS / JavaScript — single file, no frameworks  
**Design system:** Infios Design System tokens  
**Last updated:** 2026-05-06

---

## What This Is

A high-fidelity interactive prototype of the WMS AI Agent CLI — the conversational interface through which warehouse operators and managers interact with AI agents inside Warehouse Advantage (WA). Built across 8 prompts as an additive series, each layer extending the previous without rebuilding.

---

## Shell Structure

```
[HEADER — 56px, #262523 charcoal, full width]
  WA wordmark | Warehouse Advantage | Role toggle | Notifications | User avatar

[BODY — flex row]
  [UNIFIED SIDEBAR — 260px, #1B2336 dark]
    Sessions label
    Nav items: Agent CLI / Shift log / Floor map (badge) / Agent performance / Warehouse / Settings
    + New shift button
    Session list: Today / Yesterday / Earlier (role-scoped)
    Shift log card (pending / validated / auto counts)

  [RIGHT COLUMN — flex:1]
    [SUBNAV — 40px, #E7E7E7]
    [MAIN — flex:1, #F4F4F4]
```

**Header logo area:** 260px wide, aligns with unified sidebar.  
**Subnav:** lives inside the right column (not full-width), so it never overlaps the sidebar.

---

## Views

### 1. Agent CLI (`view = 'cli'`)

Two modes, toggled via pill popover at bottom-left of the input zone:

#### Operational mode
- **Agent context bar:** agent name + warehouse/shift label + context status pulse
- **Chat thread:** user messages (right-aligned, dark bubble) + agent messages (left-aligned, white tile)
- **Action card** inside agent message:
  - URGENT badge (when `criticality === 'urgent'`)
  - Description + impact line
  - Status dot + label
  - Approve / Queue buttons (operator only, STATE 1 only)
  - "Simulate escalation →" link
- **Quick-action chips:** Shift status / Pick exceptions / Dock arrivals
- **Input zone:** textarea + send button

#### Analysis mode
- Agent `<select>` dropdown — changing agent always triggers handoff modal (never silent)
- Handoff modal: From/To agent display + editable summary textarea
  - "Switch with summary" / "Start clean — load report only"
- Analysis chat thread with BI Agent, Innovation Agent, Opportunity Agent

#### Escalation split-view (`uiState = 'cli-escalation'`)
- Triggered by "Simulate escalation →" link
- Subnav becomes condition tabs: Not logged in / No response / In approval / Shift boundary
- Left panel: action card (same structure as CLI card)
- Right panel: escalation detail — condition badge, status line, stepper, supervisor context
- Back to chat link in subnav

---

### 2. Shift Log (`view = 'log'`)

Full-width table view.

**Filter bar (chips at top):**
- State chips: All / Pending (red count) / Queued / Validated (green) / Agent actions (gray)
- Zone chips: All zones / Zone A / Zone B / Zone C / Dock bays
- Shift filter chip (when navigated from session list) — shows "Showing: Shift B — Yesterday" with clear × button

**Table columns:** State | Description | Agent | Actor (manager only) | Zone | Time

**Row backgrounds:**
- `pending + urgent` → `#FFFBE6` (warm yellow)
- `pending + standard` → `#F0F4FF` (light blue)
- `validated` → `#E6FFE6` (light green)
- `auto` → `#F4F4F4` (gray)

**STATE cell icons:**
- Pending → orange clock
- Validated → green checkmark
- Auto → gray lock

**ACTOR cell (manager only):**
- Validated: approver name, bold
- Auto: "No approval required", italic gray
- Pending: "—"

**Export button:** rendered only for managers (not hidden — absent entirely for operators).

---

### 3. Floor Map (`view = 'map'`)

Spatial warehouse view. Live agent activity pins overlaid on zone grid.

#### Zone Grid
`grid-template-columns: repeat(5,1fr)`, `grid-template-rows: repeat(3,1fr)`. Zones placed via explicit `grid-column`/`grid-row` with `span`. 8 zones: Receiving, Storage A, Storage B, Pick Zone C, Pick Zone D, Pack, Staging/Outbound, Shipping Docks.

**Role-scoped rendering:**
- Operator: own zone (`operatorZone: true` → Pick Zone C) full opacity + `border: 2px solid #5436CC`. All other zones `opacity: .6` + `pointer-events: none` on their pins.
- Manager: all zones full opacity, all pins interactive.

#### Pins
`position: absolute` inside zone, `left: posX%`, `top: posY%`, `transform: translate(-50%,-50%)`.

| Type | Color | Icon |
|------|-------|------|
| `escalated` | `#D0413A` red | Exclamation `!` |
| `awaiting` | `#5436CC` purple | Circle dot |
| `autonomous` | `#2C812C` green | Star |

Escalated pins have pulsing ring (`@keyframes pulse-ring-map`, opacity 0.4→0.8, `@media prefers-reduced-motion` guard). Resolved-queued pins: purple + 40% opacity. Rejected pins: removed from DOM. Hover shows tooltip with pin title.

**Sidebar badge:** red pill on Floor map nav item, count = unresolved escalated pins. Updates on approve/queue/downgrade. Hides at zero via `[data-zero]`.

#### Pin detail — split view (STATE 2)
Triggered by clicking any interactive pin. Layout shifts to 60/40 split (`.map-tile.split` + `.map-detail`).

**Detail panel header:** colored dot + status label + close ×.

**Detail panel body:**
- Criticality badge (`URGENT` red / `STANDARD` blue) — absent for autonomous
- Title, agent + time, zone pill
- Description text
- Impact block (amber left-border) — escalated/awaiting only, pre-resolution
- Escalation info block (red left-border, "Escalated to [name]") — escalated only
- Autonomous info block (green, "Logged automatically") + "View in action log →" link

**Action buttons (pre-resolution):**

| Pin type | Role | Buttons |
|----------|------|---------|
| `escalated` | Manager | Approve / Queue / Downgrade escalation |
| `escalated` | Operator | Info message only ("requires manager approval") |
| `awaiting` | Either | Approve / Queue |
| `autonomous` | Either | None (info block only) |

**Post-resolution states:**
- `approved` → green confirm block, pin stays visible resolved
- `queued` → blue confirm block, pin fades to 40% purple
- `downgraded` → blue confirm block, pin changes to purple awaiting type
- `rejected` → pin removed from map, detail closes

**Escalation stepper** (escalated, pre-resolution): 4-step timeline — Agent detected → Action proposed → Escalated (active) → Approved & executed (pending).

---

### 4. Agent Performance (`view = 'perf'`)

Manager/ops-manager scoped. Operators see a permission notice (lock icon, centred tile, no partial access).

#### System Health Panel
4 metric tiles in a row, dynamic threshold colors:

| Metric | Healthy | Warning | Critical |
|--------|---------|---------|----------|
| Context load latency | < 5s | 5–9.9s | ≥ 10s |
| Silent context failures | = 0 | — | > 0 |
| Role-correct routing | ≥ 90% | 80–89% | < 80% |
| Audit completeness | 100% | — | < 100% |

Stage pill: "Stage 2 baseline"

#### Shift Intelligence Card (full width, above grid)
Two-column layout: agent identity left (240px) + 2×2 metric grid right.  
Metrics: Anomalies detected 24H / Signal-to-noise ratio / Avg detection-to-alert / Est. missed anomaly rate  
Note: *"This agent feeds the Lead Agent — it does not propose actions or receive approvals."*

#### Domain Agent Grid
`grid-template-columns: repeat(auto-fill, minmax(300px, 1fr))`, 16px gap.

Each card:
- Agent avatar (colored square + initials) + name + descriptor + status pill (RUNNING / PAUSED)
- 3-column metrics row: Actions 24H | Approval Rate (threshold color + pill) | Autonomy
  - Autonomy ≥ 70% → "Stage 3 territory" amber note
- Escalation rate (green ≤2% / amber 3–5% / red >5%)
- Rejection pattern: "Normal variance" green | "Tuning needed" amber bold
  - Clustered + rejectionNote → amber left-border note block
- Cautious → Bold slider (gradient track: green→purple→red, white thumb)
  - Projected approvals / shift — updates in real-time on drag
  - Formula: ≤33 = base×0.6 | 34–66 = base | ≥67 = base×1.6
- Paused agent: slider at 50% opacity, `pointer-events:none`, paused note

**Exception Agent special treatment:**
Warning banner spans full card width (negative horizontal margin) when `approvalRate < 80 AND rejectionPattern === 'clustered'`. Only card with a problem signal in the mock data.

---

## Unified Sidebar Detail

Always visible, 260px, `#1B2336`. Part of flex layout — pushes main content right (not an overlay).

**Nav items** (`sp-nav-item`):
- Active state: `#CADF35` left border 3px + `rgba(202,223,53,0.07)` background
- Icons: 16px white stroke SVGs

**Session list** (role-scoped):
- Manager sees all shifts across all operators
- Operator sees own shifts only
- Active session: live dot animation + "Active · Berlin DC"
- Past sessions: clickable → pre-filters shift log to that shift

**Shift log card:**
- Pending approval (red badge) / Validated (green) / Agent actions (gray)
- Clickable → navigates to shift log view

**Agent performance link** (manager only, above shift log card):
- Navigates to agent performance page — not a toast

---

## New Shift Flow

1. "+ New shift" button in sidebar
2. Confirmation modal — warns if pending approvals exist
3. Confirm → archives session, updates `currentShiftLabel` to "Shift C", fires toast "Shift C started — session archived"

**Toast:** `position: fixed`, `top: 72px`, centered, 3s auto-dismiss.

---

## Data Model

### `DATA.operational`
Single shift agent conversation with one action card (SKU-4821 replenishment, URGENT).

### `DATA.analysis`
3 agents: BI / Innovation / Opportunity. Pre-loaded chat thread. Switch responses per agent. Handoff summary text.

### `DATA.escalation`
4 conditions × 6-step stepper each: `not_logged_in` / `no_response` / `in_approval` / `shift_boundary`.

### `DATA.actionLog`
5 rows: 2 pending, 1 validated, 2 auto. Used by shift log view and session navigator counts.

### `DATA.agentPerformance`
- `system`: 4 health metrics
- `shiftIntelligence`: radar layer agent, 4 metrics
- `agents[5]`: Pick Path / Labor / Order Priority / Carrier (paused) / Exception (WARNING)

### `DATA.floorMap`
- `warehouse`: 'DC-07 Dallas'
- `lastUpdated`: timestamp string
- `zones[8]`: each has `id`, `label`, `row`, `col`, `colSpan`, `rowSpan`, `operatorZone`
- `pins[7]`: each has `id`, `zoneId`, `type` (`escalated`|`awaiting`|`autonomous`), `posX`, `posY`, `title`, `agent`, `criticality`, `time`, `description`, `impact`, `actionId`, `status`, `escalatedTo`

---

## State Variables

```javascript
let view              // 'cli' | 'log' | 'map' | 'perf'
let uiState           // 'cli-default' | 'cli-escalation'
let mode              // 'operational' | 'analysis'
let role              // 'operator' | 'manager'
let condition         // escalation condition key
let resolution        // null | 'approved' | 'queued'
let activeAgent       // 'bi' | 'innovation' | 'opportunity'
let pendingAgent      // agent awaiting handoff confirmation
let analysisMsgs      // copy of analysis chat messages
let logStateFilter    // 'all' | 'pending' | 'queued' | 'validated' | 'auto'
let logZoneFilter     // 'all' | 'Zone A' | 'Zone B' | 'Zone C' | 'Dock bays'
let expandedRow       // row id | null
let modePopOpen       // boolean
let activeDrawer      // null (drawer system deprecated — sidebar always visible)
let currentShiftLabel // 'Shift B' | 'Shift C' (updates on new shift)
let logShiftLabel     // null | string — pre-filters shift log
let selectedPin       // pin id | null — open detail panel
let resolvedPins      // { [pinId]: 'approved' | 'rejected' | 'queued' | 'downgraded' }
```

---

## Key Design Decisions

| Decision | Reasoning |
|----------|-----------|
| Overlay drawer → push sidebar | Overlay conflicted visually with log filter column |
| Filter sidebar → top chips | Reclaimed table width; filters more scannable |
| Export button absent (not hidden) for operators | Role scoping via conditional render, not CSS visibility |
| Approve button always `#171F29` bg + `#FFFFFF` text | Yellow text on dark bg was illegible |
| Validated rows `#E6FFE6`, auto rows `#F4F4F4` | Never share visual treatment — distinct meaning |
| Mode selector in input zone, not subnav | Subnav reserved for title / breadcrumb / condition tabs only |
| Agent `<select>` always triggers handoff modal | No silent agent switches — every handoff is intentional |
| Slider projects approvals in real-time | Manager must see cost of increased autonomy before committing |
| Exception Agent warning banner: combined signal only | `approvalRate < 80 AND clustered` both required — not either alone |
| Floor map operator zone dimming | Operator scoped to own zone — other zones' pins `pointer-events:none` + 40% opacity, not hidden |
| Rejected pins removed from DOM | Rejection is a strong signal — pin should not linger even dimmed |
| Downgrade changes pin type to awaiting (purple) | Escalation removed but action still needs approval — visual type must reflect new state |
| Sidebar badge hides at zero via `[data-zero]` attr | CSS `display:none` on attribute avoids empty red pill cluttering nav |

---

## Files

| File | Description |
|------|-------------|
| `wms-unified.html` | Primary prototype — all prompts 5–8 |
| `wms-agent-cli-full.html` | Prompt 4 — dual-mode CLI + escalation split-view |
| `wms-escalation.html` | Earlier escalation prototype |
| `wms-agent-cli.html` | Earlier CLI prototype |
| `admin-panel.html` | Visual reference for shell design |

---

## Localhost

Server runs on `http://localhost:3456`  
Direct link: `http://localhost:3456/wms-unified.html`
