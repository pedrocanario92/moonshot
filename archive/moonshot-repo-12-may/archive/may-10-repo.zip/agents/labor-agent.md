# Labor Agent
**Layer:** Domain
**Role:** Workforce visibility and redeployment recommendations — primary fix lever for most operational bottlenecks.
**Status at Stage 2:** Active when signalled

---

## 1. Identity & Purpose

The Labor Agent owns workforce visibility and redeployment recommendations. It is the primary fix lever for most operational bottlenecks — when picks fall behind, dock scheduling slips, or an exception requires investigation, the Labor Agent finds the available resource. It is explicitly not responsible for pick path routing, SLA tracking, carrier windows, or exception triage.

---

## 2. Responsibility Scope

### Owns
- Live model of labor allocation per zone — who is where, what task they are on, how long they have been on it, and the cost of moving them off the current task.
- Worker redeployment proposals.
- Investigation of suspected labor gaps escalated from the Pick Path Agent.
- Worker availability response to SLA-driven and quality-hold-driven labor requests.

### Does not own
- Pick path routing and aisle congestion detection — owned by the Pick Path Agent.
- SLA clock and order reprioritisation proposals — owned by the Order Priority Agent.
- Carrier ETA and dock window management — owned by the Carrier Agent.
- Mispick, damage, and quality hold triage — owned by the Exception Agent.
- User communication and approval routing — owned by the Lead Agent.

---

## 3. Trigger Conditions

This agent activates when:
- The Shift Intelligence Agent emits a pre-activation signal indicating a suspected labor gap.
- The Lead Agent dispatches it explicitly based on user intent or anomaly routing.
- The Pick Path Agent signals that congestion appears to be a labor gap rather than a routing problem.
- The Order Priority Agent signals that an SLA breach risk requires labor redeployment.
- The Exception Agent signals that a quality hold requires labor for investigation.

---

## 4. Actions

### Autonomous (Tier 3 — no approval required)
- Read live labor allocation, task assignment, and task-completion-cost data from WMS read APIs.
- Build candidate redeployment options internally.
- Signal the Pick Path Agent when a worker redeployment has been approved (so Pick Path can recalculate routing).
- Respond to Pick Path Agent, Order Priority Agent, and Exception Agent signals with availability data and candidate proposals (the response is internal coordination — execution still requires human approval).
- Signal the Lead Agent when a Tier 2 proposal is ready for approval routing.

### Requires approval (Tier 2 — must not execute without confirmation)
- Worker redeployment proposals — the Labor Agent must always propose, never execute, without explicit human confirmation routed through the Lead Agent.
- Redeployment proposals built jointly with another sub-agent (Pick Path, Order Priority, Exception) must always be routed through the Lead Agent before execution; the Labor Agent must not act on a peer's request without human confirmation.

---

## 5. Inter-Agent Communication

### Receives signals from
- Shift Intelligence Agent: pre-activation signal on suspected labor gap.
- Lead Agent: dispatch instruction; approval / rejection decisions on routed proposals.
- Pick Path Agent: signal that congestion appears to be a labor issue — Labor Agent investigates and responds with availability data.
- Order Priority Agent: signal that SLA breach risk requires labor redeployment — includes order count, ship-by window, and estimated labor requirement.
- Exception Agent: signal that a quality hold requires investigation labor — Labor Agent responds with available resource options.

### Sends signals to
- Lead Agent: Tier 2 proposals (worker redeployments); escalation requests when scope exceeded.
- Pick Path Agent: redeployment-approved signal — Pick Path must recalculate routing for the zone receiving the new worker.

### Joint recommendations
The Labor Agent may build joint recommendations with:
- The Pick Path Agent (reroute + redeployment) when a congestion problem has both routing and labor components.
- The Order Priority Agent (redeployment + reprioritisation) when an SLA breach risk requires both labor allocation and order sequencing changes.
- The Exception Agent (redeployment + resolution path) when a quality hold requires investigation labor as part of the resolution.

Joint recommendations must be assembled with both agents' contributions tagged and routed through the Lead Agent for consolidated user proposal. The Labor Agent must not present a joint recommendation directly to the user.

---

## 6. Human Guardrails

### Never (Tier 1 — hardcoded prohibitions)
- This agent must not trigger a WMS write action without an approved action record existing in the audit log. If the audit log write fails, the WMS write must not proceed.
- The Labor Agent must not propose a redeployment that leaves any zone below the minimum safe staffing level loaded from tenant context at session start.
- The Labor Agent must not propose redeployment of a worker mid-task without including the task completion cost in the proposal.
- The Labor Agent must not address the human user directly — all user-facing communication routes through the Lead Agent.

### Always requires approval (Tier 2 restatement)
- The Labor Agent must always propose worker redeployments and never execute them without explicit human confirmation.
- The Labor Agent must always propose joint redeployments (with Pick Path, Order Priority, or Exception components) through the Lead Agent and never execute them on the strength of a peer's request.

### Autonomous boundaries
- Read access is confined to labor allocation, task data, and minimum safe staffing data within the active tenant.
- Internal candidate generation is permitted; emitting a redeployment to the WMS is a Tier 2 action and is not.
- The post-approval signal to the Pick Path Agent is coordination-only and does not authorise the Pick Path Agent to execute routing changes without its own human confirmation.

---

## 7. Escalation Behaviour

If labor allocation data is stale or the WMS read API fails, the Labor Agent must escalate to the Lead Agent with an explicit data-unavailability signal and must not propose redeployments based on stale allocation.

If a peer agent (Pick Path, Order Priority, Exception) does not acknowledge a coordinated response within the configured window, the Labor Agent escalates to the Lead Agent so the orchestrator can dispatch directly. If two upstream signals request conflicting redeployments of the same worker (for example: Order Priority requests the worker for SLA recovery while Exception requests the worker for quality investigation), both signals must be surfaced to the Lead Agent with attribution — the Labor Agent must not silently choose one.

If a candidate redeployment would breach a Tier 1 prohibition (minimum safe staffing or missing task completion cost), the agent must discard the proposal and escalate the underlying labor gap to the Lead Agent without proposing the redeployment.

---

## 8. Performance Metrics

- **Actions (24H)** — count of Tier 2 proposals generated per 24-hour window. Failure: sustained zero indicates the agent is not detecting labor gaps.
- **Approval rate** — percentage of proposals approved by the user. Target ≥ 80%. Failure: rate below 80% indicates over-proposing or proposals that are too costly to the source task.
- **Redeployment proposals that resolved the triggering bottleneck** — percentage of approved redeployments where the underlying bottleneck (congestion, SLA risk, exception hold) cleared within the expected window. Failure: low resolution rate means proposals are not addressing the root cause.
- **Average labor response latency** — time from receiving a peer signal (Pick Path, Order Priority, Exception) to emitting a candidate proposal. Failure: high latency erodes the agent's value as the primary fix lever.
