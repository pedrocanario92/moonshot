Claude Code Prompt — WMS Agent CLI Prototype
ROLE & TASK
You are a senior frontend engineer building a high-fidelity UI prototype for a WMS (Warehouse Management System) AI Agent CLI. This is not a generic chatbot — it is a dual-mode, multi-agent interface designed for warehouse operators and supervisors managing daily shift operations. The prototype must feel like a production-ready enterprise tool, not a demo. Build it as a single self-contained HTML file using vanilla HTML, CSS, and JavaScript only — no frameworks, no external dependencies except Google Fonts.
VISUAL REFERENCE & DESIGN SYSTEM
Base your entire visual language on the attached admin-panel_1.html file.
Extract and reuse these exact values — do not invent alternatives:
/* Shell colors */
--wa-header-bg:   #262523;   /* charcoal header */
--wa-nav-bg:      #324154;   /* navy sidebar */
--wa-nav-accent:  #CADF35;   /* brand yellow — use for active states and CTAs */
/* Infios DS tokens */
--infios-font-family: 'Noto Sans', sans-serif;
--infios-color-bg:                   #FFFFFF;
--infios-color-bg-alt:               #F4F4F4;
--infios-color-bg-fill-brand:        #171F29;
--infios-color-text:                 #171F29;
--infios-color-text-secondary:       #324155;
--infios-color-text-tertiary:        #58636E;
--infios-color-text-link:            #5436CC;
--infios-color-border-tertiary:      #D5DCE2;
--infios-color-bg-fill-success-subtle: #E6FFE6;
--infios-color-bg-fill-warning-subtle: #FFFBE6;
--infios-color-bg-fill-error-subtle:   #FFF0F0;
--infios-color-text-success:         #2C812C;
--infios-color-text-warning:         #B64C00;
--infios-color-text-error:           #D0413A;
--infios-radius-desktop: 8px;
--infios-shadow-card: 0 2px 8px rgba(35,38,37,0.10);
/* 8pt spacing grid */
--infios-spacing-2xs: 8px;
--infios-spacing-xs:  12px;
--infios-spacing-s:   16px;
--infios-spacing-m:   20px;
--infios-spacing-l:   24px;
--infios-spacing-2xl: 32px;
Shell structure to replicate exactly:
56px charcoal header (#262523) with logo left, user avatar right
48px navy icon sidebar (#324154) on the left
40px gray subnav (#E7E7E7) below the header
Main content area fills remaining space with #F4F4F4 background
All content panels use white #FFFFFF surface with 8px border-radius andbox-shadow: 0 2px 30px 0 rgba(0,0,0,0.15)
BUILD PLAN — 3 SEQUENTIAL PROTOTYPES IN ONE FILE
Build all three views inside a single HTML file. Use hash-based routing (#view1, #view2, #view3) to switch between them. Add a persistent top navigation strip (inside the subnav bar) with three labeled tabs so the reviewer can navigate between prototypes without editing the URL.
PROTOTYPE 1 — Dual-Mode CLI Shell (#view1)
What it is: The main chat interface with a mode toggle betweenOperational and Analysis. This is the primary screen the user lands on.
Layout:
Keep the full platform shell (header + sidebar + subnav)
The subnav shows the mode toggle as a two-option segmented control:Operational | Analysis — switching modes changes the agent context visually
Main area: a chat panel (476px wide, right-pinned, same as the referencechat-panel) with a message thread and input bar
Left of the chat panel: a status sidebar showing the active agent name, current tenant/warehouse name, and a session health indicator (green dot = context loaded, red dot = context error)
Operational mode active state:
Agent name shown: Shift Agent
Subnav accent pill in #CADF35 yellow
Three quick-action chips above the input bar:Shift status · Pick exceptions · Dock arrivals
Show a pre-populated example conversation:
User: "How many picks are behind target this hour?"
Agent (Shift Agent): "23 picks behind target in Zone B. Primary cause: SKU-4821 staging delay. Replenishment recommended — awaiting your approval."
Show an inline approval card below the agent message with:
Action label: "Trigger replenishment — SKU-4821, 200 units"
Criticality badge: URGENT in red (#D0413A bg, white text)
Two buttons: Approve (primary, brand dark) · Queue (secondary outline)
Analysis mode active state:
Agent name shown: BI Agent
Subnav accent in #5436CC purple
Agent switcher row above the input bar showing three agent pills:BI (active) · Innovation · Opportunity
Show a pre-populated example conversation:
User: "Summarise this week's pick error rate trend."
Agent (BI Agent): "Pick error rate averaged 3.2% this week, up from 2.8% last week. Peak errors occurred Tuesday 14:00–16:00. Zone C accounts for 61% of errors."
PROTOTYPE 2 — Analytical Agent Switching with Handoff Preview (#view2)
What it is: The moment a user switches analytical agents mid-conversation. This is a modal-style interaction that overlays the chat.
Layout:
Render the Analysis mode chat view as the background (same as Prototype 1 Analysis state, slightly dimmed with rgba(23,31,41,0.35) overlay)
Overlay a centred modal card (480px wide) using the DS modal shadow:box-shadow: 0 4px 24px rgba(35,38,37,0.18)
Modal content — three sections:
Header: "Switch to Innovation Agent" — bold 16px, close icon top-right
Handoff preview panel (the critical design moment):
Label: "Handoff summary" in tertiary text, 12px
A bordered text block (bg #F4F4F4, border #D5DCE2, 8px radius) showing the auto-generated summary: "BI Agent found: pick error rate 3.2% this week (+0.4pp WoW). Peak on Tuesday 14:00–16:00. Zone C = 61% of errors. User was exploring whether Zone C layout is the root cause."
Below the summary: a small info note in tertiary text: "Review before switching — the Innovation Agent will use this as its starting context."
Choice row:
Primary button: Switch with summary (brand dark, full width)
Secondary link below: Start clean — load report only
Interaction: Clicking Switch with summary closes the modal and shows a new chat message from the Innovation Agent: "Interesting starting point. Zone C errors peaking Tuesday afternoon — before assuming it is a layout problem, consider: is Tuesday the day Zone C receives its largest replenishment? That would implicate slotting strategy, not layout."
PROTOTYPE 3 — Approval Gate with Criticality Tagging (#view3)
What it is: The full approval workflow — showing both the urgent escalation path and the standard queue path, with a criticality classifier visible to the user.
Layout:
Use the full platform shell
Main content area is a two-column layout:
Left column (420px): Active chat thread with an agent-proposed action
Right column (flex 1): Approval detail panel — the action in full context
Left column — chat thread:Show a short conversation:
User: "We are running low on SKU-7732 in Zone A."
Agent (Shift Agent): "Stock for SKU-7732 in Zone A is at 12 units — below the 50-unit reorder threshold. I recommend triggering replenishment: 200 units from Bay 4 staging. This action is tagged URGENT — it will block Zone A picks within 40 minutes if not actioned."
Inline action card (same pattern as Prototype 1):
Action: "Replenish SKU-7732 Zone A — 200 units from Bay 4"
Criticality badge: URGENT
Buttons: Approve · Queue
Right column — approval detail panel:Show a white panel with:
Panel header: "Pending approval" with a count badge 1
The full action card expanded:
Action title: "Replenish SKU-7732 — Zone A"
Criticality row: URGENT badge + explanation text: "Escalates to next available supervisor if not approved within 5 minutes"
Proposed by: "Shift Agent · 14:32"
Impact statement: "Blocking: Zone A pick lanes 3–6 in ~40 min"
Approve button (primary, full width, brand dark)
Divider + "Not available?" link that expands to show the escalation path: "Will escalate to → Warehouse Manager (J. Santos) if no response by 14:37"
Below that: a second queued item (Standard criticality):
Action: "Update dock schedule — Bay 2 arrival window +30 min"
Criticality badge: STANDARD in blue (#2B7AB1)
Status: "Queued — will resurface at next supervisor login"
Interaction: Clicking Approve on the urgent item:
Changes the badge to APPROVED in green (#2C812C)
Shows a success confirmation bar at the top of the panel: "Replenishment triggered — SKU-7732, 200 units. Logged at 14:33."
Removes the urgent item from the queue after 2 seconds
EXAMPLE OF EXPECTED OUTPUT QUALITY
The prototype should look and feel like a screen from the admin-panel_1.htmlreference — same shell, same tokens, same component density. A reviewer should not be able to tell visually that one was the reference and one was generated.
Key quality markers:
Agent messages use a light gray bubble (#F4F4F4 bg, 8px radius)
User messages use the brand dark bubble (#171F29 bg, white text, 8px radius)
All status badges use pill shape (border-radius: 9999px)
Approval cards sit inside the chat thread as inline cards — white bg,1px solid #D5DCE2 border, 8px radius, 8px internal padding
The criticality tag is always visible and always the first element in the approval card — never buried
Transitions on mode toggle and modal open/close: 150ms ease
CRITICAL INSTRUCTIONS — READ BEFORE WRITING ANY CODE
Single file only. All HTML, CSS, and JS in one .html file. No imports except Google Fonts (Noto Sans) and no external JS libraries.
Reuse the exact design tokens from the reference file listed above. Do not invent new colors, spacing values, or font sizes. If a value is not listed above, derive it from the 8pt grid (4, 8, 12, 16, 20, 24, 32px).
Replicate the shell exactly. The 56px charcoal header, 48px navy sidebar, and 40px gray subnav must match the reference file structure. The prototype navigation tabs live inside the subnav — do not add a new bar.
All three prototypes must be navigable from the subnav tab strip without reloading the page. Use display: none / block toggling on view containers.
The approval card criticality tag is always the first visible element.Never let it appear after text. Its position communicates urgency — treat it as a layout constraint, not a decoration.
Prototype 2 modal must not use position: fixed in a way that collapses the layout. Use a full-viewport overlay div with position: fixed; inset: 0and center the modal card inside it using flexbox.
No placeholder lorem ipsum. All content must be warehouse-domain-specific as specified in this prompt. Use the exact copy provided — do not paraphrase.
The handoff summary in Prototype 2 must be editable. Render it as a<textarea> pre-filled with the summary text, not a static <p>. The user should be able to edit before switching.
Deliver working interactions for: mode toggle (P1), agent switcher pills (P1 Analysis), modal open/close with both handoff paths (P2), approve action with confirmation state (P3). Everything else can be static.
CRITICAL — Do not change the design system. The Infios DS tokens are non-negotiable. No purple gradients, no Inter font, no rounded-everything aesthetic. This must look like a WMS enterprise tool.