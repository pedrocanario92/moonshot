# Chatbot — Admin Panel Project Context

## Project Overview

We are designing the **Admin Panel** for the **AI Chatbot assistant** embedded in the Infios **Warehouse Advantage** platform (legacy K.One). The chatbot answers questions about Infios Warehouse Management System product documentation.

This project has two distinct but related workstreams:

1. **Chatbot UI** — The conversational interface users interact with day-to-day
2. **Admin Panel** — A dedicated settings/management area for admins to manage the chatbot's knowledge base

---

## Platform Context

The product lives inside the **Warehouse Advantage (K.One)** legacy platform, which has:

- Dark navy sidebar (`#324154`) with icon-only navigation (hamburger, grid, star, list)
- Top header bar with Infios logo, product name ("Warehouse Advantage"), and right-side icons: chat, bell, help, user profile
- Secondary action bar beneath the header
- Font: Noto Sans
- Brand colors: dark navy `#324154`, charcoal `#262523`, slate `#58636E`, light grey `#E7E7E7`, yellow-green accent

The design must integrate with this existing shell — no new color systems, no purple, no off-brand styling.

---

## The Chatbot UI (Prototype 1 — Main Focus)

### Entry Point
A chat/forum icon in the top header bar. When active, it highlights in yellow-green.

### Layout Modes
- **Side panel** — Chat opens as a right-side panel (~1/3 screen width). Platform content remains visible on the left.
- **Expanded / Full-width** — Chat takes over the full content area. "Assistant" label appears in sub-nav. Platform sidebar collapses.
- **Small panel** — Compact inline floating format for use over table views.

### States Designed (Figma Prototype 1)
| State | Description |
|---|---|
| Empty / Welcome | Panel opens with assistant intro message + terms & conditions link |
| Conversation | User message (gray bubble, right-aligned) + AI response (plain text, left-aligned, formatted) |
| Feedback — Positive | Thumbs up turns yellow/active |
| Feedback — Negative | Opens "Your feedback is important" modal with free-text field |
| Expanded | Full-screen mode, sidebar collapses |

### Panel Header Controls
Refresh (new chat), History, Expand/Collapse, Close (X)

### Message Actions (on AI response)
Thumbs up, Thumbs down, Copy, Three-dot menu

### Welcome Message (current copy — name TBD)
> "Hello, I am your Infios Product Documentation assistant. I'm here to help you with any questions you have about Infios Warehouse Management System product documentation. Just ask away! Also, please take a moment to review our terms and conditions."

### Input Field
Placeholder: "Ask anything...." — Send button (dark navy with yellow-green arrow icon)

---

## The Admin Panel — Strategic Decision

### What the PO Originally Asked For
The PO and dev team built an admin panel **embedded inside the chatbot widget** itself. Accessible via an admin/shield icon in the chat input bar, it replaced the chat view with:
- Two tabs: Document Library / Embedding workspace
- Stats cards (Total, Ready, In progress, Failed)
- Document table with agent assignment, status, upload date, and actions
- Upload modal with drag & drop, per-file description and agent assignment
- Confirmation dialogs for delete, retry, and cancel embedding

Visual language: purple header (`#6B5EA8`), off-brand — does not match Infios design system.

### Why This Approach Is Wrong
1. **Role collision** — Chat is for end users; document management is for admins. Mixing both in a single 400px panel creates cognitive overload and blurs role boundaries.
2. **Scalability** — The document library needs search, filters, bulk actions, and pagination as it grows. A chat-sized panel cannot scale to that.
3. **Permission model** — A settings page makes role-based access control natural. An icon buried in a chat input bar does not.
4. **Industry standards** — Claude, Gemini, ChatGPT, and every major enterprise platform (Salesforce, ServiceNow) separate admin/settings from the end-user conversation interface.

### What We Are Building Instead
The Admin Panel becomes a **dedicated full-page experience** within the platform's standard navigation flow — not embedded in the chatbot widget.

**Key structural decision from the raw concept (see `inspiration/admin-panel-raw-concept.png`):**
- Uses the full Warehouse Advantage platform shell (Infios header, standard layout)
- Left sidebar navigation with collapsible sections: "Admin panel" > "Document library", "Embedding workspace"
- Main content area with full-width document management: stats cards + data table + "Upload documents" CTA
- Upload modal follows standard platform patterns: drag & drop zone, file list with validation, Cancel / Upload actions
- No purple. No embedded widget. Proper page.

---

## Admin Panel — Feature Scope

### Document Library
- Stats summary: Total Documents, Ready, In progress, Failed (color-coded)
- Document table columns: Document (name), Agent (assigned), Status, Uploaded (date), Actions
- Per-row actions:
  - **Delete** — Trash icon → confirmation: "This would permanently delete the document from the database. Are you sure?"
  - **Retry** — Circular arrow → confirmation: "Retry document ingestion?"
  - **Cancel** — Circle X (only on In progress rows) → confirmation: "This would stop the document embedding. Are you sure?"
- Inline agent reassignment via dropdown (options: `documentation_agent`, `labor_coaching_agent`, Unassigned)
- Status color coding: Ready = default, In progress = yellow/orange, Failed = red

### Embedding Workspace
- Second tab/section (details TBD — not fully specced in the PO's PDF)

### Upload Flow
1. Click "Upload documents" → opens modal
2. Drag & drop zone or "Browse files" button
3. PDF only, Max 1GB per file, multiple files supported
4. Per file: filename shown, description field (required), agent assignment dropdown
5. Confirmation on file removal: "Are you sure you don't want to upload this document and remove it?"
6. Upload button becomes active once all files have descriptions and agent assignments
7. Success: files appear in Document Library table with status "In progress" → transitions to "Ready" or "Failed"

---

## UX Goals & Design Principles

From the alignment email shared with the team:

> "By aligning the interface with the design patterns found in tools like Gemini, Claude, and ChatGPT, we aim to provide a more natural and conversational flow for our users."

### Three Core Objectives
1. **Reduce the Learning Curve** — Leverage familiar UI patterns to make the tool instantly accessible
2. **Improve Discoverability** — Features and insights should be intuitive to find and use
3. **Ensure Consistency** — New screens must fully integrate with the current Infios software visual language

### UX Gaps to Address in the Chatbot UI (vs. Claude/Gemini standards)
1. No empty-state suggested prompts — add example questions on the welcome screen
2. No typing / loading indicator — add streaming animation or "thinking" state
3. Timestamps on every message add noise — remove or show only on hover
4. Feedback thumbs-down modal is too heavy — consider inline lightweight feedback
5. No conversation history sidebar — history icon exists but no conversation list is shown
6. No AI avatar / identity marker on responses — consider a small assistant icon or label
7. "Refresh" icon for new chat is ambiguous — use a compose/pencil icon instead
8. No conversation title / session label
9. Full-screen expansion removes all platform context abruptly

---

## Figma File Reference

**File:** Chat-Bot (`cPFwuUmkaHVDFpvuVCTdGX`)

| Prototype | Starting Node | Description |
|---|---|---|
| Prototype 1 (main focus) | `405:8439` | Old platform (Warehouse Advantage / K.One) |
| Prototype 2 | `405:13259` | Alternative concept |

### Key Frame IDs — Prototype 1
| Node ID | State |
|---|---|
| `405:8439` | Empty state — WA base UI, no chatbot panel |
| `405:8709` | Conversation — full-width panel |
| `405:8981` | Conversation — side panel with sidebar |
| `405:9271` | Conversation + feedback modal |
| `405:9586` | Thumbs up active state |
| `405:9729` | Thumbs down active state |
| `405:13877` | Small panel — empty/welcome state |
| `405:14387` | Small panel — conversation state |

---

## Deliverables

- [ ] Admin Panel — full-page settings experience (Document Library + Embedding Workspace)
- [ ] Chatbot UI — updated to modern conversational standards
- [ ] Both aligned to Infios visual language (Warehouse Advantage shell)
- [ ] Present to PO by end of week (week of April 14, 2026)

---

## Inspiration & References

See `inspiration/` folder:
- `admin-panel-raw-concept.png` — Raw sketch of admin panel as a full-page within the Warehouse Advantage platform shell. Shows left nav sidebar, document library main area, upload modal with file list and validation.

---

## Key People

- **Paulo Osório** — Lead Designer, UX team owner for this project
- Platform: Infios Warehouse Advantage (K.One legacy)

---

## Design Approach & Skills

When working on this project, apply the following skills in order of priority:

### Phase 1 — Current focus

**UX Process (`ai-ux-process`)**
Apply this skill when making interaction decisions, defining flows, structuring information hierarchy, and evaluating patterns against industry standards (Claude, Gemini, ChatGPT). Every screen should be evaluated through this lens before visual decisions are made.

**Design System Thinking (`design-system-thinker` + `infios-design-system-figma`)**
Apply this skill when selecting or defining components, tokens, spacing, and typography. All decisions must reference the Infios Design System and the Warehouse Advantage visual language. No custom one-off patterns that diverge from the DS. This ensures the output is consistent, scalable, and ready to be handed off to dev.

### Phase 2 — Planned later

**UIKit (`infios-uikit` / `infios-uikit-react`)**
A second iteration of the designs will be produced specifically targeting implementation with the Infios UIKit component library. This phase focuses on mapping every element to actual UIKit components and generating production-ready code.
