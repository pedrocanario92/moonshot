You are building a WMS (warehouse management system) agentic UX prototype as a single self-contained HTML file. Output ONE complete HTML document — inline CSS and JS, no external assets, no build step. The file must run by double-clicking it in a browser.

## The argument the prototype must demonstrate

UX practitioners must own the AI capabilities being built around their discipline. The prototype shows an approval-first agentic system for a warehouse: every agent proposes, no agent executes alone. Human-in-the-loop is structural, not decorative. The user — a warehouse manager named Dana Whitaker working shift A at DC-14 Memphis, TN — sees a calm dashboard that surfaces decisions only when one is actually needed.

## Personas (use these names verbatim — no Portuguese names, no other locations)

- Reyna Castillo — Operator (shift A)
- Marcus Hale — Shift Supervisor
- Dana Whitaker — Warehouse Manager (the user)
- DC-14 Memphis, TN — the facility
- Shift A — the active shift, 08:00 to 16:00

## Agent roster — every WMS agent uses the same schema

Schema per agent action: `{ agent, confidence (0-100), proposal, reasoning, escalationReason?, options?: [{label, tradeoff}] }`. When confidence is low or the choice is genuinely ambiguous, the agent surfaces `options[]` with "N options drafted · no recommendation chosen" — buttons become Open / Defer / Why? instead of Approve / Reject.

WMS topology (in-fiction, user-visible):
- **Lead Agent** — orchestration, sole human-facing agent, runs the chat thread
- **Shift Intelligence Agent** — radar layer, signal-only, never proposes
- **Pick Path Agent** — pick sequencing, replen risk
- **Labor Agent** — staff reassignment
- **Order Priority Agent** — wave resequencing
- **Carrier Agent** — cutoffs, lane changes
- **Exception Agent** — transactional errors only (NOT damage/holds — those belong to Quality)
- **Slotting Agent** — replenishment scheduling, bin assignment, fast-mover re-slotting (adapted from Allen Oleksak's demo)
- **Equipment Agent** — forklifts, AMRs, conveyors, charge cycles, equipment faults (adapted from Allen Oleksak's demo — new domain)
- **Quality Agent** — damage, quality holds, cycle counts (adapted from Allen Oleksak's demo — carved out of old Exception scope)
- **BI · Innovation · Opportunity** — analytical layer, analysis mode only

Meta (backstage, drives the sim — give it its own card on any Agents page):
- **Warehouse Life Agent** — scripted-causal simulation engine. Emits root events on an 08:00–09:30 timeline; causal rules derive secondary events. Not in the WMS topology — it IS the simulated warehouse.

Guardian (process gate, audits the prototype itself — give each its own card):
- **Heuristics Agent** — Nielsen Norman 10 + Hick's Law + Miller's 7±2 + cognitive load + F-pattern + banner blindness + information scent
- **Accessibility Agent** — WCAG 2.2, AA load-bearing, AAA advisory

## Three patterns explicitly REJECTED (do not include)

- No "Handled by agents" autonomous-action feed on the home page — autonomous actions live in the action log only
- No three-side-by-side parallel queues — one inline focus card + queue chip
- No single Cautious↔Bold autonomy slider — categorical Tier 1/2/3 constraints instead

## Layout — the manager dashboard (default home view)

CSS grid, four columns and two rows:
- `grid-template-columns: minmax(180px, 1fr) minmax(0, 1fr) minmax(0, 1fr) minmax(300px, 22%)`
- `grid-template-areas: "zones stage stage terminal" "kpi1 kpi2 kpi3 terminal"`

**Zones strip (left column, top row):** six warehouse zones (Receiving, Storage, Picking, Packing, Shipping, Returns), each row a 3×2 grid with a status dot + name + rate metric on top row, and a thin capacity bar spanning the bottom. Bar fill = `load %`. Bar color: green on-target, brand-blue at `load ≥ 85` ("running hot"), amber for zones with active incidents. Attention zones get a 1.6s pulse animation on their status dot.

**Stage (center, top row, spans two columns):** elevated white card with generous padding and `box-shadow: 0 2px 30px 0 rgba(0,0,0,0.15)`. Calm hero state: green status dot + "All zones on target" + last-updated chip. When an incident fires, the stage gets dimmed and a centered modal appears with incident detail + agent proposal + Approve/Reject/Open/Defer (or Open/Defer/Why? for options[] escalations).

**KPI strip (bottom row, three cells):** three tiles, each a 2-column grid with `grid-template-areas: "val trend" "lbl trend" "cap trend"`. Left half holds value + label + caption; right half holds a 100×44 SVG sparkline + arrow + delta. KPIs:
- `1,284 · ORDERS IN FLIGHT · "active across all waves"` — neutral polarity
- `97% · ON-TIME · "shipping by carrier cutoff"` — up is good
- `0 · OPEN ITEMS · "decisions waiting on you"` — down is good

Sparklines drift deterministically each sim-minute. Use a ring buffer of 10 snapshots per KPI; compute trend as mean-of-last-3 vs mean-of-first-3.

**Terminal (right column, spans both rows):** soft-dark chat panel. Background `#1E2530`, brand-yellow `#CADF35` agent name tags, cyan `#67E8F9` user prompt prefix, Noto Sans Mono. Header `> lead@dc-14-memphis · LIVE` with a green pulse dot. Messages in flat terminal-line format: `[time] LA  body` — no bubbles. Input bar has a cyan `>` prefix and a brand-yellow caret. Timestamps in `#9CA3AF` (5.6:1 contrast on the dark bg — must pass AA).

## Other views (sidebar items)

- **Floor map** — pins for incidents, zone overlay
- **Shift log** — chronological action log with operator attribution
- **Agent performance** — per-agent stats (actions24h is illustrative, not live-bound)
- **Agent CLI** — the same chat thread, full-bleed dark terminal that fills the entire main area (no light outer frame)
- **Warehouse dashboard** — a snapshot operational view (NOT live-bound to the sim — this is "the whole operation today" not "this moment"). Cards: orders shipped today + on-time shipping + pick accuracy + active labor (with sparklines) · full-width hourly throughput bar chart · wave progress · inventory health · inbound · putaway · picks · pack · returns · equipment · safety · carrier mix

## Cross-page incident banner

When a new pending decision or escalation fires while the user is on Map / Log / Perf / CLI, a floating banner slides down at the top of the right column: `position: absolute; top: 8px; left: 20px; right: 20px; z-index: 30` inside the right column. Open button navigates back to Home; Dismiss only hides the banner. The banner overlays — never pushes content down.

## The sim

- Sim clock starts at 08:00, advances every 500ms wall-time at 30:1 compression — full demo runs in ~3 wall-minutes
- Seven root events on the 08:00–09:30 timeline; two are user-facing (Pick Path replen at 08:30 sim, Equipment escalation at 08:50 sim); one autonomous Labor reassign and one autonomous Order Priority resequence flow through the action log only
- Causal rules: late inbound → Pick Path replen risk; low-confidence equipment fault → `options[]` escalation with no recommendation chosen
- Restart shift button resets to 08:00

## Visual system

- Universal tile pattern everywhere: `border: none`, `border-radius: 8px`, `box-shadow: 0 2px 30px 0 rgba(0,0,0,0.15)`. Pills, banners, modals keep their own chrome.
- Selective re-render: each view has a signature gate so it only re-renders on real state changes. Home modal lives in its own persistent DOM host outside the home template so it doesn't retrigger its fade-in animation on every tick.
- Sidebar badge semantics: red for urgent pending, orange for standard pending, hidden when zero, green for validated, blue for info.

## Constraints

- Single HTML file. No external scripts, no external stylesheets, no fonts that require network.
- Must pass WCAG 2.2 AA on all measured contrast pairs.
- Must pass Nielsen Norman 10 heuristics — accept that the dashboard is structurally denser than a focal stage, but competing affordances in the calm state must be zero.
- No `alert()` placeholders. Every Details / Why button opens a real modal with the agent's reasoning, audit ID, options breakdown, and a "Decision lives with you" footer.

Build it. Output the complete HTML file. Begin.
