You are building a WMS agentic UX prototype as a single self-contained HTML file. The agent specs are already in this working directory under `agents/`. Read them — they are the spine of the system.

## Step 1 — read these files end-to-end in this order

1. `agents/lead-agent.md` — the orchestration layer and sole human-facing agent
2. `agents/shift-intelligence-agent.md` — the radar layer (signal-only)
3. `agents/pick-path-agent.md`, `agents/labor-agent.md`, `agents/order-priority-agent.md`, `agents/carrier-agent.md`, `agents/exception-agent.md` — the original Domain agents
4. `agents/slotting-agent.md`, `agents/equipment-agent.md`, `agents/quality-agent.md` — Domain agents adapted from Allen Oleksak's demo
5. `agents/analytical-agents.md` — BI / Innovation / Opportunity
6. `agents/meta/warehouse-life-agent.md` — the simulation engine that drives the events the WMS agents react to
7. `agents/guardian/heuristics-agent.md` and `agents/guardian/accessibility-agent.md` — the audit gate the prototype must pass

Every WMS agent spec follows the same eight-section structure (Identity, Scope, Triggers, Actions, Communication, Guardrails, Escalation, Metrics) and every action carries `confidence` (0–100), `escalationReason` (when bowing out), and `options[]` (when no recommendation is chosen). Honor that schema in the runtime.

## Step 2 — build a single self-contained HTML file

The prototype shows a warehouse manager (Dana Whitaker, shift A, DC-14 Memphis, TN) on a calm dashboard that surfaces decisions only when one is needed. Approval-first: every agent proposes, no agent executes alone. The argument the prototype makes is that UX practitioners must own the AI capabilities being built around their discipline.

### Layout — manager dashboard (default view)

A four-column CSS grid with two rows. Left column: zones strip with capacity bars + per-zone rate metrics + a pulse-attention status dot. Center (spans two columns of the top row): elevated white stage card, calm hero ("All zones on target") in the default state, centered incident modal over a dimmed dashboard when an incident fires. Right column (spans both rows): soft-dark terminal chat panel hosting the Lead Agent's voice — Noto Sans Mono, `#1E2530` background, brand-yellow `#CADF35` agent name tags, cyan `#67E8F9` user prompt prefix, terminal-line message format `[time] LA  body`. Bottom row (three cells across zones + stage width): KPI strip with sparklines on the right half of each tile, semantic polarity (green up for on-time, green down for open items, neutral for orders in flight).

Other views accessible from the sidebar: Floor map, Shift log, Agent performance, Agent CLI (full-bleed dark terminal version of the same chat), and Warehouse dashboard (a snapshot operational view — roughly fifteen cards covering shipped / on-time / accuracy / labor / hourly throughput / waves / inventory / inbound / putaway / picks / pack / returns / equipment / safety / carrier mix; NOT live-bound to the sim).

### Sim engine

The Warehouse Life Agent spec is the source of truth for the timeline. Sim clock from 08:00, 30:1 compression (~3 wall-minutes per shift hour). Seven root events on the 08:00–09:30 timeline; two are user-facing (Pick Path replen ~08:30 sim, Equipment escalation ~08:50 sim — the Equipment one is a low-confidence `options[]` escalation with no recommendation chosen); the rest are autonomous actions that appear in the action log only, never on the home page. Causal rules: late inbound → Pick Path replen risk; low-confidence equipment fault → `options[]` escalation.

### Visual system

Universal tile pattern everywhere: `border: none`, `border-radius: 8px`, `box-shadow: 0 2px 30px 0 rgba(0,0,0,0.15)`. Pills, banners, modals keep their own chrome. Cross-page incident banner floats above content with `position: absolute; top: 8px; left: 20px; right: 20px; z-index: 30` inside the right column — never pushes content down. Selective re-render per view (signature gate) so the screen doesn't flicker every sim tick. The home incident modal must live in its own persistent DOM host outside the home template so it doesn't retrigger its fade-in on every tick.

### Patterns to reject (the Guardian audit will catch these — don't include them)

- No "Handled by agents" autonomous-action feed on the home page
- No three-side-by-side parallel queues
- No single Cautious↔Bold autonomy slider — Tier 1/2/3 categorical constraints instead
- No `alert()` placeholders — every Details / Why button opens a real modal with the agent's reasoning, audit ID, options breakdown, and a "Decision lives with you" footer

### Constraints

- One HTML file. No external scripts, no external stylesheets, no network fonts.
- Must pass WCAG 2.2 AA on all measured contrast pairs (terminal timestamps must be at least `#9CA3AF` on `#1E2530` — 5.6:1).
- Must pass Nielsen Norman 10 heuristics — competing affordances in the calm state must be zero, even though the dashboard is structurally denser than a focal stage.

## Step 3 — write a post-mortem

After the HTML file, write a short post-mortem (`postmortem.md`-shaped) addressing:

1. Which agent specs were sufficient on their own?
2. Which required you to invent details that weren't in the spec? List them.
3. Where do the specs contradict each other or under-specify? Be specific — file + section + the gap.
4. What would you add to the agent specs to make them production-grade — i.e., enough that a fresh Claude session could build a fully-equivalent prototype without inventing details?

This is an MVP test of the agent definitions. The post-mortem is the actual deliverable; the HTML is the byproduct that proves the test was run.
