# Prompt prototype — one-shot agent-driven builds

This folder holds two prompts that test the central hypothesis of the project: **do the agent specs in `/agents/` consistently drive good interfaces, or are they just documentation?**

Both forms ask a fresh Claude session to build the WMS agentic UX prototype in a single shot. Neither will produce byte-identical output to `moonshot prototype/moonshot-prototype.html` — LLMs are stochastic and the prototype is ~4,700 lines of dense HTML/CSS/JS. The test is **structural consistency**: same agents, same dashboard shape, same approval semantics, same visual language. If both forms produce recognizable, working prototypes that pass the Guardian audits, the agent specs are doing their job.

## How to run

1. Open a fresh Claude chat (no prior context).
2. Paste the entire contents of `PROMPT.md` from one of the two subfolders.
3. Save the resulting HTML next to the prompt as `output.html`.
4. Open `output.html` in a browser. Verify it loads. Run the Guardian audits (`agents/guardian/heuristics-agent.md` and `agents/guardian/accessibility-agent.md`).
5. For Form B specifically: the prompt asks Claude to write a short post-mortem about which agent specs were sufficient and which under-specified. That post-mortem is the actual deliverable — save it as `postmortem.md` alongside `output.html`.

## The two forms

| Folder | Form | What it tests |
|---|---|---|
| `full prompt prototype/` | A — mega-prompt with everything inlined | The upper bound: can Claude build it in one go if given everything in the same message? |
| `agent loaded prototype/` | B — agents folder + focused build prompt | The real hypothesis: are the spec files in `/agents/` alone enough? |

Form B is the real MVP. Form A is the control.

## What to compare

After running both:

- Did either produce a shippable artifact (renders cleanly, no console errors, passes Guardian audits)?
- Which produced the more complete prototype? What was missing from the other?
- For Form B: which agent specs need tightening based on the post-mortem? Those edits are the next round of work.
